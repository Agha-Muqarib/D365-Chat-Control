import React, { createContext, useContext, useState } from 'react';

interface MyContextType {
  sharedValue: string;
  setSharedValue: React.Dispatch<React.SetStateAction<string>>;
}

const MyContext = createContext<MyContextType | undefined>(undefined);

export const useMyContext = () => {
  const context = useContext(MyContext);
  if (!context) {
    throw new Error('useMyContext must be used within a MyProvider');
  }
  return context;
};

interface ExpiryTimeProviderProps {
  children: React.ReactNode;
}

const ExpiryTimeProvider: React.FC<ExpiryTimeProviderProps> = ({ children }) => {
  const [sharedValue, setSharedValue] = useState('This value is accessible across components');

  return (
    <MyContext.Provider value={{ sharedValue, setSharedValue }}>
      {children}
    </MyContext.Provider>
  );
};

export default ExpiryTimeProvider;